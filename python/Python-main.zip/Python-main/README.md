# Python

This directory contains programs and projects that utilize Python and illustrate several topics that can be done in the programming language. These programs are followed from the **Fundamentals of Python: First Programs** by Kenneth Alfred Lambert

## Installation

In order to run the files, the device must have python installed. If not, please reference the following link to help install it.
- Download Python: https://www.python.org/downloads/

***Remember!*** These links should be used as **reference** to help better understand how to add python on your device
