"""
Student Name: Aimee Valladares
Purpose: Illustrates user input, simple calculations, and print statements.
"""

width = int(input("Enter the width: "))
length = int(input("Enter the length: "))
area = width * length
print("The area is", area, "square units")