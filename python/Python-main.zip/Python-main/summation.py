"""
Student Name: Aimee Valladares
Purpose: Introduces user input, print statements, variables, and simple calculations.
"""

first = int(input("Enter the first number: "))
second = int(input("Enter the second number: "))
sum = first + second
print("The sum is", sum)
